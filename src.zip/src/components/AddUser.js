import { render } from "@testing-library/react"

function AddUser(props){
    const addUser=(e)=>{
        e.preventDefault();
        const data=e.target.elements.uname.value
        props.addUserdata(data)
    }
    return(
        <div>
            <form onSubmit={addUser}>
            Username<input type="text" name="uname"/>
                <button>Add User</button>
            </form>
        </div>
    )
}
export default AddUser