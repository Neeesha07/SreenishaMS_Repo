import { Component } from "react";
import HeaderComponent from "./Header";
import FooterComponent from "./Footer";
import UserList from "./USerList";
import AddUser from "./AddUser";

export default class MainApp extends Component{
    
    state={
        users:["manager","admin","employee"]
    }
    addUser=(input)=>{
        this.setState((prevState)=>{
            return{
                users:prevState.users.concat(input)
            }
        })
    }
    render(){

        const headerdata="This is header";
        const footerdata="This is footer";
    
            return(
            <>
            <header>
            <HeaderComponent hd={headerdata}/>
            </header>

            <div>
                <h2>
                    Welcome to MainApp
                </h2>
                <p>
                    <AddUser addUserdata={this.addUser}/>
                    <UserList list={this.state.users}/>
                </p>
             
            </div>
            <footer>
            <FooterComponent fd={footerdata}/>
            </footer>
            </>
        )
    }
}