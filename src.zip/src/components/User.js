function User(props){
    return(
        <>
       
        <div>
           
            {props.udata}
        </div>
        </>
    )
}
export default User